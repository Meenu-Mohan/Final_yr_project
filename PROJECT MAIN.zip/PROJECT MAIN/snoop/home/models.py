from django.db import models
import os
from django.utils import timezone


def upload_to(instance, filename):
    # Get the filename and extension
    base_filename, ext = os.path.splitext(filename)
    # Construct the directory path using the instance name
    directory = 'juveniles/{}'.format(instance.name)
    # Construct the full file path
    filepath = '{}/{}{}'.format(directory, base_filename, ext)
    return filepath

# Create your models here.

SEX_CHOICES = (
    ('Male','Male'),
    ('Female','Female'),
)

class Juveniles(models.Model):
    name = models.CharField(max_length=100)
    juvenile_img = models.ImageField(upload_to=upload_to)
    sex = models.CharField(choices=SEX_CHOICES, max_length=10)
    age = models.IntegerField()
    dob = models.DateField()
    weight = models.FloatField()
    height = models.FloatField()
    address = models.TextField()
    missing = models.BooleanField(default=False)
    missing_date = models.DateField(default=None, blank=True, null=True)
    more_img = models.ImageField(upload_to=upload_to, blank=True)