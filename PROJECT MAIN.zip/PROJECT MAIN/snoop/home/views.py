from django.shortcuts import render
from .models import Juveniles
from django.http import HttpResponse

# Create your views here.
def index(request):

    juvs = Juveniles.objects.all()

    return render(request, 'index.html',{'juvs':juvs})